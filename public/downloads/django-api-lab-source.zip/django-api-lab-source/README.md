# Django API Lab — source extract

These are the actual implementation files used by the Django API Lab demo
on Alexender's portfolio. The download is for reading the code and adapting the
component within a suitable React project. It is not a standalone application
or a published npm package.

## What the demo does

A TypeScript browser simulation of a small read-only task API. It illustrates JSON, status codes, query filters, and validation. It does not run Python, send API requests, or connect to a database. The Python sketch in the component is explanatory; a real Django project would also need its model, routing, settings, and validation.

## Included source

- `src/components/projects/django-api-lab.tsx`

`MANIFEST.sha256` records a SHA-256 checksum for each included file and this guide.
The request simulator and explanatory Python sketch are both contained in the included component.

## Using the component

The original site uses Next.js, React, TypeScript, Tailwind CSS, and lucide-react.
The component is a client component and uses browser APIs. The import alias
`@/` points to `src/` in the portfolio's TypeScript configuration.

Copy the files into a React/TypeScript project with matching dependencies and
an equivalent alias, then import and render `DjangoApiLab`. Adapt the
styles to your application. The component uses Tailwind utility classes, shared
`.button` variants, and design variables such as `--bg`, `--surface`,
`--surface-soft`, `--text`, `--muted`, `--line`, `--green`, and `--accent`.
Those site-wide styles and the application shell are not included in this
focused source extract. Browser storage and downloads should be exercised in
the browser, rather than during server rendering.

## Checking behaviour

Use the demo to inspect list, detail, invalid-query, and missing-task responses. This source extract does not include an automated test suite.

The build notes on `/projects/django-api-lab/#behind-the-build` describe decisions,
manual examples to explore, current limitations, and a possible next step.
These are demonstration projects; no client outcomes or performance results
are claimed by this source download.

## Refreshing the download

From the complete portfolio source, run:

```sh
python3 scripts/export-project-sources.py
```

The script uses an explicit allowlist. Environment files, contact settings,
credentials, dependencies, and build output are never part of these downloads.
The generated ZIPs are static assets; Python is not needed by the deployed site.
