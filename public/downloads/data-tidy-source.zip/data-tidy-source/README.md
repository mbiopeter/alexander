# Data Tidy — source extract

These are the actual implementation files used by the Data Tidy demo
on Alexender's portfolio. The download is for reading the code and adapting the
component within a suitable React project. It is not a standalone application
or a published npm package.

## What the demo does

A browser CSV tool for parsing, trimming, blank-row removal, deduplication, preview, and local download. The parser supports quoted commas, escaped quotes, and embedded newlines. Inputs are limited to 120,000 characters, 2,000 parsed rows, and 50 columns. The optional spreadsheet text protection changes formula-like cells, including negative-number text, by prefixing an apostrophe.

## Included source

- `src/components/projects/data-tidy.tsx`
- `src/lib/demo-utils.ts`
- `src/lib/demo-utils.test.ts`

`MANIFEST.sha256` records a SHA-256 checksum for each included file and this guide.
The shared helper module contains both the board reader and the CSV utilities; it is preserved exactly as used by the portfolio.

## Using the component

The original site uses Next.js, React, TypeScript, Tailwind CSS, and lucide-react.
The component is a client component and uses browser APIs. The import alias
`@/` points to `src/` in the portfolio's TypeScript configuration.

Copy the files into a React/TypeScript project with matching dependencies and
an equivalent alias, then import and render `DataTidy`. Adapt the
styles to your application. The component uses Tailwind utility classes, shared
`.button` variants, and design variables such as `--bg`, `--surface`,
`--surface-soft`, `--text`, `--muted`, `--line`, `--green`, and `--accent`.
Those site-wide styles and the application shell are not included in this
focused source extract. Browser storage and downloads should be exercised in
the browser, rather than during server rendering.

## Checking behaviour

The helper test file uses Node's built-in test runner and TypeScript. From the full portfolio with dependencies installed, run `node --import tsx --test src/lib/demo-utils.test.ts`. It covers CSV parsing, cleanup and serialization, spreadsheet text protection, and the saved-board data reader. It is not an end-to-end UI test suite.

The build notes on `/projects/data-tidy/#behind-the-build` describe decisions,
manual examples to explore, current limitations, and a possible next step.
These are demonstration projects; no client outcomes or performance results
are claimed by this source download.

## Refreshing the download

From the complete portfolio source, run:

```sh
python3 scripts/export-project-sources.py
```

The script uses an explicit allowlist. Environment files, contact settings,
credentials, dependencies, and build output are never part of these downloads.
The generated ZIPs are static assets; Python is not needed by the deployed site.
